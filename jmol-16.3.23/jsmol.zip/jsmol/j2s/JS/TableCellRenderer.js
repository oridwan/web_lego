Clazz.declarePackage("JS");
Clazz.declareInterface(JS, "TableCellRenderer");
;//5.0.1-v7 Thu May 08 14:17:10 CDT 2025
