Clazz.declarePackage("JS");
Clazz.load(["JS.JMenuItem"], "JS.JCheckBoxMenuItem", null, function(){
var c$ = Clazz.declareType(JS, "JCheckBoxMenuItem", JS.JMenuItem);
Clazz.makeConstructor(c$, 
function(){
Clazz.superConstructor(this, JS.JCheckBoxMenuItem, ["chk", 2]);
});
});
;//5.0.1-v7 Thu May 08 14:17:10 CDT 2025
