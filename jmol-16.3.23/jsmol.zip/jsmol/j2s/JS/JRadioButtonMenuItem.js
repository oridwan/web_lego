Clazz.declarePackage("JS");
Clazz.load(["JS.JMenuItem"], "JS.JRadioButtonMenuItem", null, function(){
var c$ = Clazz.decorateAsClass(function(){
this.isRadio = true;
Clazz.instantialize(this, arguments);}, JS, "JRadioButtonMenuItem", JS.JMenuItem);
Clazz.makeConstructor(c$, 
function(){
Clazz.superConstructor(this, JS.JRadioButtonMenuItem, ["rad", 3]);
});
});
;//5.0.1-v7 Thu May 08 14:17:10 CDT 2025
