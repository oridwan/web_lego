Clazz.declarePackage("JSV.common");
(function(){
var c$ = Clazz.declareType(JSV.common, "ZoomEvent", null);
/*LV!1824 unnec constructor*/})();
;//5.0.1-v7 Thu May 08 14:17:10 CDT 2025
