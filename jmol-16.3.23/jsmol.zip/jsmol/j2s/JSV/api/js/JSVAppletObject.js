Clazz.declarePackage("JSV.api.js");
Clazz.declareInterface(JSV.api.js, "JSVAppletObject", javajs.api.js.JSAppletObject);
;//5.0.1-v7 Thu May 08 14:17:10 CDT 2025
