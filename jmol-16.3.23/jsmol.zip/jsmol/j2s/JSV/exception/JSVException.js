Clazz.declarePackage("JSV.exception");
Clazz.load(["java.lang.Exception"], "JSV.exception.JSVException", null, function(){
var c$ = Clazz.declareType(JSV.exception, "JSVException", Exception);
});
;//5.0.1-v7 Thu May 08 14:17:10 CDT 2025
