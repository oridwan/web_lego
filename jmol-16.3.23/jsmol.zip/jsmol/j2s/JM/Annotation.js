Clazz.declarePackage("JM");
Clazz.load(["JM.ProteinStructure"], "JM.Annotation", null, function(){
var c$ = Clazz.declareType(JM, "Annotation", JM.ProteinStructure);
});
;//5.0.1-v7 Sun May 18 19:15:32 CDT 2025
