Clazz.declarePackage ("JS");
Clazz.load (["JS.TableColumn"], "JS.AbstractTableModel", null, function () {
Clazz.declareInterface (JS, "AbstractTableModel", JS.TableColumn);
});
